package com.flightapp;

/*import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
*/
//@SpringBootTest
class SpringbootKafkaProducerApplicationTests {

	//@Test
	void contextLoads() {
	}

}
